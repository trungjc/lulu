<?php
//OpenCart Extension
//Project Name: OpenCart News
//Author: Fanha Giang a.k.a fanha99
//Email (PayPal Account): fanha99@gmail.com
//License: Commercial
?>
<?php
// Heading 
$_['heading_title'] = 'Sản phẩm liên quan';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>
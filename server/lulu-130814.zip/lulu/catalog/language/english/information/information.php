<?php
// Text
$_['text_error'] = 'Information Page Not Found!';
?>
<?php
// Text
$_['text_title_addcart']       = 'Product added to cart';
$_['text_title_wishlist']       = 'Product added to wish list';
$_['text_title_compare']       = 'Product added to compare';
$_['text_title_view']       = 'View';

?>
<?php
// Heading 
$_['heading_title'] = "Lulu's Love List";

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>
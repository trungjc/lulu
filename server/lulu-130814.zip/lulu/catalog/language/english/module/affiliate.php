<?php
// Heading 
$_['heading_title']    = 'Affiliate';

// Text
$_['text_register']    = 'Register';
$_['text_login']       = 'Login';
$_['text_logout']      = 'Logout';
$_['text_forgotten']   = 'Forgotten Password';
$_['text_account']     = 'My Account';
$_['text_edit']        = 'Edit Account';
$_['text_password']    = 'Password';
$_['text_payment']     = 'Payment Options';
$_['text_tracking']    = 'Affiliate Tracking';
$_['text_transaction'] = 'Transactions';
?>

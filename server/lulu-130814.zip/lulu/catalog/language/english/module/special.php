<?php
// Heading 
$_['heading_title'] = 'you might also like';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>
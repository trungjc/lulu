<?php
// Heading 
$_['heading_title'] = 'Recently Viewed';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>
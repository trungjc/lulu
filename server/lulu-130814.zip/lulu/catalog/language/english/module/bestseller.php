<?php
// Heading 
$_['heading_title'] = 'Best sellers';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>
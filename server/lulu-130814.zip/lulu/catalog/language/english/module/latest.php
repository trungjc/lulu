<?php
// Heading 
$_['heading_title'] = 'new arrivals';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>
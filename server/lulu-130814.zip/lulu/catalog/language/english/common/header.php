<?php
// Text
$_['text_home']           = 'Home';
$_['text_wishlist']       = 'Wish List (%s)';
$_['text_shopping_cart']  = 'Shopping Cart';
$_['text_search']         = 'Search';
$_['text_welcome']        = '<a href="%s">Sign In</a> / <a href="%s">Register</a>.';
$_['text_logged']         = '<a href="%s" style="display:none">%s</a><a href="%s">Logout</a>';
$_['text_account']        = 'My Account';
$_['text_checkout']       = 'Checkout';
?>